<?php
class iPhoenixService{	
	
	/**
	 * Get data submited by the client
	 */ 
	public static function data() 
	{
		$request = file_get_contents('php://input');
		$data = array();
		if ($request) {
			if ($json_post = CJSON::decode($request)){
				$data = $json_post;
			}else{
				parse_str($request,$variables);
				$data = $variables;
			}
		}
		
		$list_params = array_merge($_GET,$_POST);

		foreach($list_params as $index=>$param){
			if ($param) {
				if(is_array($param)){
					$data[$index]=$param;
				}
				else{
					if (CJSON::decode($param)){
						$data[$index]=CJSON::decode($param);
					}else{
						$data[$index]=$param;
					}
				}
			}
		}
		return $data;
	}
}